const Sequelize = require('sequelize');
const database = require('./banco');

const Usuário = database.define('usuários', {
nome: {
    type: Sequelize.TEXT,
    allowNull: false
},
email: {
    type: Sequelize.TEXT,
    allowNull: false,
},
telefone: {
    type: Sequelize.INTEGER,
    allowNull: false
},

cpf: {
type: Sequelize.STRING(11),
allowNull: false,
unique: true
},

senha: {
type: Sequelize.STRING,
allowNull: false
}
})

Usuário.sync({force: false}).then(() => {});

module.exports = Usuário;