const Sequelize = require("sequelize")
const sequelize = new Sequelize("test", "root", "",{
  host:"localhost",
  dialect:"mysql"
})

sequelize.authenticate().then(function(){
  console.log('banco de dados conectado com sucesso')
}).catch(function(erro){
  console.log("falha ao concetar no banco" + erro)
})

module.exports = sequelize;
